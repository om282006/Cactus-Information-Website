const mongoose = require('mongoose');

const cactusSchema = new mongoose.Schema({
  commonName: { type: String, required: true },
  scientificName: { type: String },
  origin: { type: String },
  description: { type: String },
  care: { type: String },
  water: { type: String },
  sunlight: { type: String },
  imageUrl: { type: String },
  tags: [String]
}, { timestamps: true });

module.exports = mongoose.model('Cactus', cactusSchema);
