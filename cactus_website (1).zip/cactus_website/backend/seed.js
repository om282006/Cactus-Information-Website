// Run this once to seed sample cacti (node seed.js)
const mongoose = require('mongoose');
const Cactus = require('./models/Cactus');
const MONGO = process.env.MONGO_URI || 'mongodb://localhost:27017/cactusdb';
const data = [
  {
    commonName: 'Golden Barrel',
    scientificName: 'Echinocactus grusonii',
    origin: 'Mexico',
    description: 'A round, golden spiny cactus.',
    care: 'Low maintenance. Bright light.',
    water: 'Low - water sparingly.',
    sunlight: 'Full sun',
    tags: ['easy', 'indoor']
  },
  {
    commonName: 'Christmas Cactus',
    scientificName: 'Schlumbergera bridgesii',
    origin: 'Brazil',
    description: 'Blooms in winter with colorful flowers.',
    care: 'Moderate watering, bright indirect light.',
    water: 'Moderate',
    sunlight: 'Indirect sunlight',
    tags: ['flowering', 'indoor']
  }
];

mongoose.connect(MONGO).then(async ()=>{
  await Cactus.deleteMany({});
  await Cactus.insertMany(data);
  console.log('Seeded sample data');
  process.exit(0);
}).catch(err=>console.error(err));
