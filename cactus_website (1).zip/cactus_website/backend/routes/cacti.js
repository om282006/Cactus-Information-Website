const express = require('express');
const router = express.Router();
const Cactus = require('../models/Cactus');
const auth = require('../middleware/auth');
const multer = require('multer');
const upload = multer({ dest: __dirname + '/../uploads/' });

// Public: list with basic filters & pagination
router.get('/', async (req, res) => {
  try {
    const { page = 1, q, tag } = req.query;
    const PAGE = Math.max(1, parseInt(page));
    const perPage = 12;
    const filter = {};
    if (q) filter.$or = [{ commonName: new RegExp(q, 'i') }, { scientificName: new RegExp(q, 'i') }];
    if (tag) filter.tags = tag;
    const total = await Cactus.countDocuments(filter);
    const items = await Cactus.find(filter).skip((PAGE-1)*perPage).limit(perPage).sort({ createdAt: -1 });
    res.json({ total, page: PAGE, perPage, items });
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: 'Server error' });
  }
});

router.get('/:id', async (req, res) => {
  try {
    const c = await Cactus.findById(req.params.id);
    if (!c) return res.status(404).json({ message: 'Not found' });
    res.json(c);
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: 'Server error' });
  }
});

// Admin-protected: add cactus (multipart for image)
router.post('/', auth, upload.single('image'), async (req, res) => {
  try {
    if (req.user.role !== 'admin') return res.status(403).json({ message: 'Forbidden' });
    const body = req.body;
    const c = new Cactus({
      commonName: body.commonName,
      scientificName: body.scientificName,
      origin: body.origin,
      description: body.description,
      care: body.care,
      water: body.water,
      sunlight: body.sunlight,
      tags: body.tags ? body.tags.split(',').map(t => t.trim()) : []
    });
    if (req.file) {
      c.imageUrl = '/uploads/' + req.file.filename;
    }
    await c.save();
    res.json(c);
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: 'Server error' });
  }
});

// Admin: edit
router.put('/:id', auth, async (req, res) => {
  try {
    if (req.user.role !== 'admin') return res.status(403).json({ message: 'Forbidden' });
    const update = req.body;
    const c = await Cactus.findByIdAndUpdate(req.params.id, update, { new: true });
    res.json(c);
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: 'Server error' });
  }
});

// Admin: delete
router.delete('/:id', auth, async (req, res) => {
  try {
    if (req.user.role !== 'admin') return res.status(403).json({ message: 'Forbidden' });
    await Cactus.findByIdAndDelete(req.params.id);
    res.json({ message: 'Deleted' });
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: 'Server error' });
  }
});

module.exports = router;
