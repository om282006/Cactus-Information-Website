import React, {useEffect, useState} from 'react';
import { Link } from 'react-router-dom';

export default function CactusList(){
  const [items, setItems] = useState([]);
  const [q, setQ] = useState('');
  useEffect(()=> {
    fetch('/api/cacti')
      .then(r=>r.json())
      .then(data => setItems(data.items || []))
      .catch(console.error);
  }, []);
  const search = (e) => {
    e.preventDefault();
    fetch('/api/cacti?q=' + encodeURIComponent(q))
      .then(r=>r.json())
      .then(data=> setItems(data.items || []))
      .catch(console.error);
  };
  return (
    <div>
      <h2>Cactus List</h2>
      <form onSubmit={search} style={{marginBottom:12}}>
        <input placeholder="Search by name" value={q} onChange={e=>setQ(e.target.value)} />
        <button type="submit">Search</button>
      </form>
      <div className="grid">
        {items.map(i=>(
          <div className="card" key={i._id}>
            <h4>{i.commonName}</h4>
            <p><em>{i.scientificName}</em></p>
            <p>{i.origin}</p>
            <p className="center"><Link to={'/cactus/'+i._id}>View</Link></p>
          </div>
        ))}
      </div>
    </div>
  );
}
