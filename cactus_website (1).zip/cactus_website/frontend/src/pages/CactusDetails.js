import React, {useEffect, useState} from 'react';
import { useParams } from 'react-router-dom';

export default function CactusDetails(){
  const { id } = useParams();
  const [item, setItem] = useState(null);
  useEffect(()=> {
    if(!id) return;
    fetch('/api/cacti/' + id)
      .then(r=>r.json())
      .then(setItem)
      .catch(console.error);
  }, [id]);
  if(!item) return <div>Loading...</div>;
  return (
    <div>
      <h2>{item.commonName} <small><em>{item.scientificName}</em></small></h2>
      {item.imageUrl && <img src={item.imageUrl} alt={item.commonName} style={{maxWidth:300}} />}
      <div className="card">
        <h4>About</h4>
        <p>{item.description}</p>
        <h4>Care</h4>
        <p>{item.care}</p>
        <p><strong>Water:</strong> {item.water} | <strong>Sunlight:</strong> {item.sunlight}</p>
      </div>
    </div>
  );
}
