import React, {useState} from 'react';
export default function Admin(){
  const [form, setForm] = useState({commonName:'',scientificName:'',origin:'',description:'',care:'',water:'',sunlight:'',tags:''});
  const handle = (e) => setForm({...form, [e.target.name]: e.target.value});
  const submit = async (e) => {
    e.preventDefault();
    const token = localStorage.getItem('token');
    if(!token) return alert('Please login as admin first.');
    const fd = new FormData();
    Object.keys(form).forEach(k=>fd.append(k, form[k]));
    const res = await fetch('/api/cacti', { method: 'POST', headers: { Authorization: 'Bearer ' + token }, body: fd });
    const data = await res.json();
    if (res.ok) {
      alert('Added');
      setForm({commonName:'',scientificName:'',origin:'',description:'',care:'',water:'',sunlight:'',tags:''});
    } else alert(data.message || 'Error');
  };
  return (
    <div>
      <h2>Admin Dashboard</h2>
      <form className="card" onSubmit={submit} style={{display:'grid', gap:8}}>
        <input name="commonName" placeholder="Common Name" value={form.commonName} onChange={handle} required/>
        <input name="scientificName" placeholder="Scientific Name" value={form.scientificName} onChange={handle}/>
        <input name="origin" placeholder="Origin" value={form.origin} onChange={handle}/>
        <textarea name="description" placeholder="Description" value={form.description} onChange={handle}/>
        <input name="care" placeholder="Care instructions" value={form.care} onChange={handle}/>
        <input name="water" placeholder="Water" value={form.water} onChange={handle}/>
        <input name="sunlight" placeholder="Sunlight" value={form.sunlight} onChange={handle}/>
        <input name="tags" placeholder="tags comma separated" value={form.tags} onChange={handle}/>
        <input type="file" name="image" />
        <button>Add Cactus</button>
      </form>
    </div>
  );
}
