import React from 'react';
export default function Home(){
  return (
    <div>
      <h1>Cactus Information</h1>
      <p>This website offers details, care tips and species information for many cactus plants.</p>
      <div className="card">
        <h3>Project</h3>
        <p>This project was created by the student for college coursework (You).</p>
      </div>
    </div>
  );
}
