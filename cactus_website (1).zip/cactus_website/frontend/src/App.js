import React from 'react';
import { BrowserRouter, Routes, Route, Link } from 'react-router-dom';
import Home from './pages/Home';
import CactusList from './pages/CactusList';
import CactusDetails from './pages/CactusDetails';
import Login from './pages/Login';
import Admin from './pages/Admin';

export default function App(){
  return (
    <BrowserRouter>
      <div className="app">
        <nav className="nav">
          <Link to="/">Home</Link>
          <Link to="/list">Cactus List</Link>
          <Link to="/admin">Admin</Link>
          <Link to="/login">Login</Link>
        </nav>
        <main className="container">
          <Routes>
            <Route path="/" element={<Home/>} />
            <Route path="/list" element={<CactusList/>} />
            <Route path="/cactus/:id" element={<CactusDetails/>} />
            <Route path="/login" element={<Login/>} />
            <Route path="/admin" element={<Admin/>} />
          </Routes>
        </main>
      </div>
    </BrowserRouter>
  );
}
